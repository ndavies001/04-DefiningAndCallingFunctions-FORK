###############################################################################
# DONE: 1. (2 pts)
def hello():
    print ("This is beginning to make sense")
hello()
#   First, let's define a function. Below this _TODO_, define a function named
#       hello()
#   that greets the user. It can say something like
#       "Hello! What a beautiful day we're having!"
#   or whatever you'd like it to say.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################

###############################################################################
# Done: 2. (1 pt)
hello()
#   Now, we need to tell that function to run (in other words, tell it to do
#   what we have defined it to do).
#
#   Below this _TODO_, call the function that you defined above. Once you have
#   done that, you can run your code and you should see your greeting printed
#   in your terminal.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################

###############################################################################
# TODO: 3. (3 pts)
#   Now, for practice, let's do that again!
def goodbye():
    print ("fare thee well dear user")
goodbye()
#
#   Define a function called
#       goodbye()
#   that prints a farwell message to the user.
#
#   Then, call the function so it actually runs.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################